package com.dicoding.picodiploma.submission2_ichsan

data class User(
    val login: String,
    val id: Int,
    val avatar_url: String
)
