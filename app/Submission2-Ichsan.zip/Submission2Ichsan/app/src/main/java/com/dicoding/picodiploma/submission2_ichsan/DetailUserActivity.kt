package com.dicoding.picodiploma.submission2_ichsan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.dicoding.picodiploma.submission2_ichsan.databinding.ActivityDetailUserBinding


class DetailUserActivity  : AppCompatActivity() {

    companion object{
        const val EXTRA_USERNAME = "extra_username"
    }
    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var viewModel : DetailUserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Detail User"

        val username = intent.getStringExtra(EXTRA_USERNAME)
        val mBundle = Bundle() //bundle berfungsi sebagai perpindahan fragment dengan membawa data
        mBundle.putString(EXTRA_USERNAME, username)

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailUserViewModel::class.java)

        viewModel.setUserDetail(username)
        viewModel.getUserDetail().observe(this) {
            if (it != null) {
                binding.apply {
                    tvName.text = it.name
                    tvUsername.text = it.login
                    tvFollowers.text = " Followers : ${it.followers}"
                    tvFollowing.text = " Following : ${it.following}"
                    tvRepost.text = " Repository : ${it.public_repos}"
                    tvComp.text = " Company : ${it.company}"
                    tvLink.text = " GitHub : ${it.html_url}"
                    tvLoc.text = " Location : ${it.location}"
                    Glide.with(this@DetailUserActivity)
                        .load(it.avatar_url)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .centerCrop()
                        .into(ivPicture)
                }

            }
        }
        val sectionPagerAdapter = SectionPagerAdapter(this, supportFragmentManager, mBundle)
        binding.apply {
            viewPager.adapter = sectionPagerAdapter
            tab.setupWithViewPager(viewPager)
        }
    }
}