package com.dicoding.picodiploma.submission2_ichsan

data class UserResponse(
    val items : ArrayList<User>
)
